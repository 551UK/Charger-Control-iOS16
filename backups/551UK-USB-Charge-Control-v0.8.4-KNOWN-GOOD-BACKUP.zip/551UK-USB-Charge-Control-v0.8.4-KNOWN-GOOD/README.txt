551UK USB Charge Control v0.8.4 — KNOWN GOOD (confirmed by user 2026-10-11)

This is a byte-for-byte archival copy of the working native .deb and source archive. Do not overwrite or alter this release while debugging charger detection.

The current-cap apply and software off/on restore have been verified on iPhone XS Max. A ~16-second lag when connecting a charger is an acknowledged remaining issue.

Native UIKit Objective-C source code:
https://github.com/551UK/Replaced-Screen-Battery/blob/cc7e417f2240e503f6f385d849972614bea58106/ios-usb-charge-control/USBChargeControl.m

