from pathlib import Path
import shutil, re, os, subprocess, zipfile, plistlib
root=Path('/mnt/data')
old=root/'551UK-USB-Charge-Control-v0.8.3-stage'
new=root/'551UK-USB-Charge-Control-v0.8.4-stage'
if new.exists():shutil.rmtree(new)
shutil.copytree(old,new)
backend=new/'var/jb/usr/libexec/551uk-usb-currentd.py'
panel=new/'var/jb/usr/libexec/usb_control_panel.py'
a=backend.read_text();b=panel.read_text()
search="        self.restorebase=sig(self.accessory,'IOAccessoryManagerRestoreUSBCurrentLimitBase',C.c_int,[U])\n"
assert a.count(search)==1
a=a.replace(search,search+"        self.powerignore=sig(self.accessory,'IOAccessoryManagerSetUSBPowerIgnore',C.c_int,[U,U])\n        self.preventsource=sig(self.accessory,'IOAccessoryManagerSetUSBPreventSourceDetection',C.c_int,[U,U])\n")
# use one Lightning service regardless of previously latched USB status, for re-enabling the path.
start='    def read(self,acc):\n'
assert a.count(start)==1
a=a.replace(start,'''    def lightning_context_allow_ignored(self):
        """Open the actual Lightning accessory port even if ignore disables its status.

        This intentionally bypasses context()'s charging-attached requirement ONLY
        for restoring USBPowerIgnore=0 / PreventSourceDetection=0.
        """
        match=self.match(b'IOAccessoryManager')
        if not match:raise RuntimeError('IOAccessoryManager unavailable')
        iterator=C.c_uint32(0)
        rc=self.services(0,match,C.byref(iterator))
        if rc:raise RuntimeError(f'IOServiceGetMatchingServices 0x{rc & 0xffffffff:08x}')
        found=None;conn=C.c_uint32(0)
        try:
            while True:
                obj=self.iterator_next(iterator.value)
                if not obj:break
                name,_=self.registry_info(obj)
                if name!='Port-Lightning':
                    self.release(obj);continue
                opened=self.open(obj,self.taskport,0,C.byref(conn))
                if opened==0 and conn.value:
                    found=obj;break
                self.release(obj)
        finally:
            if iterator.value:self.release(iterator.value)
        if found is None:raise RuntimeError('Port-Lightning not openable for power restore')
        return found,conn.value

'''+start)
# driver commands run inside same privileged python helper
needle="                elif command=='RESTORE':\n"
assert a.count(needle)==1
a=a.replace(needle,"""                elif command=='RESTART':
                    # Only the native UI sends RESTART; package maintenance and
                    # legacy diagnostics still send plain RESTORE (no power pulse).
                    result=control_panel.do_restore('native-app-or-package-removal')
                    if not result['ok']:
                        conn.sendall(('ERR '+result['message']+'\\n').encode()[:400]);continue
                    restart=control_panel.do_power_restart('native-app')
                    conn.sendall(('OK 0\\n' if restart['ok'] else 'ERR '+restart['message']+'\\n').encode()[:400])
                    continue
"""+needle)
needle="    if len(sys.argv)==4 and sys.argv[1]=='--panel-watchdog':\n"
assert a.count(needle)==1
a=a.replace(needle,"""    if len(sys.argv)==3 and sys.argv[1]=='--usb-power-watchdog':
        control_panel.init(sys.modules[__name__],LOG)
        sys.exit(control_panel.usb_power_watchdog(sys.argv[2]))
"""+needle)
a=a.replace("USB current daemon 0.8.3 boot:","USB current daemon 0.8.4 boot:")
backend.write_text(a)
# panel
needle="TOKENFILE=PRIVATE/'web-token'\n"
assert b.count(needle)==1
b=b.replace(needle,needle+"POWER_MARKER=PRIVATE/'power-restart.json'\n")
# insert reboot methods before old _post_restore_audit
needle="def _post_restore_audit(reason):\n"
assert b.count(needle)==1
b=b.replace(needle,'''def _power_recover_once(label):
    """Always return BOTH Apple USB power flags to their normal (zero) state.

    Reacquires Port-Lightning WITHOUT requiring it to report actively attached;
    the port can temporarily appear disconnected while power is ignored.
    """
    api=CORE.IO();acc,conn=api.lightning_context_allow_ignored()
    try:
        result1=api.preventsource(conn,0)
        result2=api.powerignore(conn,0)
        note(f'USB SOFT REPLUG RESUME ({label}) preventSource=0x{result1 & 0xffffffff:08x} powerIgnore=0x{result2 & 0xffffffff:08x}')
        return result1==0 and result2==0
    finally:
        api.close(conn);api.release(acc)


def usb_power_watchdog(session):
    # Independent process: survives launchd daemon death, enforces upper bound.
    # The session marker is root-only and only removed after BOTH clears succeed.
    time.sleep(5)
    try:
        if not POWER_MARKER.exists() or POWER_MARKER.is_symlink():return 0
        entry=json.loads(POWER_MARKER.read_text())
        if entry.get('session')!=session:return 0
        for i in range(6):
            try:
                if _power_recover_once('watchdog-'+str(i+1)):
                    POWER_MARKER.unlink(missing_ok=True);return 0
            except Exception as exc:note('USB POWER WATCHDOG recover failed '+repr(exc))
            time.sleep(2)
        note('USB POWER WATCHDOG: unable to clear power-ignore; physically unplug/replug the charging cable')
        return 80
    except Exception as exc:
        note('USB POWER WATCHDOG failed '+repr(exc));return 81


def do_power_restart(reason='native-app'):
    """EXPERIMENTAL: emulate a power-source change, NOT a proven cable detach.

    Apple ioupsd uses SetUSBPreventSourceDetection and SetUSBPowerIgnore
    with 1 in one power state and 0 in the other. We request a 1-second
    off/on transition, log actual input-rail measurements and independently
    recover both flags even after a crash. ONLY explicit native action.
    """
    with serialized():
        state=read_state()
        if state:
            return {'ok':False,'message':'Charging cap still active; no power restart performed.'}
        before=snapshot()
        if before.get('plugged')!=1 or before.get('charging')!=1:
            note('USB SOFT REPLUG skipped: must be charging from Lightning')
            return {'ok':False,'message':'Connect a wired charger and start charging first.'}
        if before.get('usb_max_ma') is not None:
            return {'ok':False,'message':'Another USB maximum remains; software power restart skipped.'}
        api=CORE.IO();acc,conn=api.context()
        session=secrets.token_hex(16)
        armed=False
        try:
            # Declare the recovery obligation BEFORE any hardware write.
            atomic_bytes(POWER_MARKER,json.dumps({'session':session,'time':time.time()}).encode())
            armed=True
            watcher=subprocess.Popen([sys.executable,'-B','-s',str(Path(CORE.__file__).resolve()),'--usb-power-watchdog',session],
                stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,close_fds=True)
            note(f'USB SOFT REPLUG START ({reason}): inputW={before.get("system_mw")}mW inputMA={before.get("system_ma")}mA batteryMA={before.get("battery_ma")}mA baselineUSB={before.get("usb_ma")}mA watchdogPID={watcher.pid}')
            # Battery-case system code pairs these flags; no CPU/GPU/thermal write.
            disable_source=api.preventsource(conn,1)
            disable_inflow=api.powerignore(conn,1) if disable_source==0 else -1
            note(f'USB SOFT REPLUG OFF: preventSource=0x{disable_source & 0xffffffff:08x} powerIgnore=0x{disable_inflow & 0xffffffff:08x}')
            if disable_source!=0 or disable_inflow!=0:
                return {'ok':False,'message':'USB power-off command failed; recovery requested.'}
            time.sleep(1.2)
            off=snapshot()
            note(f'USB SOFT REPLUG OFF TELEMETRY: plugged={off.get("plugged")} charging={off.get("charging")} inputMA={off.get("system_ma")} inputW={off.get("system_mw")}')
        except Exception as exc:
            note('USB SOFT REPLUG exception '+repr(exc))
            return {'ok':False,'message':'Software power restart error; recovery requested.'}
        finally:
            try:
                # Primary direct restore of both power flags, using the original
                # port handle in case it is temporarily missing from IOKit.
                ra=api.preventsource(conn,0)
                rb=api.powerignore(conn,0)
                note(f'USB SOFT REPLUG FINALLY ON: prevent=0x{ra & 0xffffffff:08x} ignore=0x{rb & 0xffffffff:08x}')
                cleared=(ra==0 and rb==0)
                if not cleared:
                    try:cleared=_power_recover_once('fallback-new-connection')
                    except Exception as exc:note('USB SOFT REPLUG fallback error '+repr(exc))
                if cleared and armed:POWER_MARKER.unlink(missing_ok=True)
            except Exception as exc:
                note('USB SOFT REPLUG restore exception '+repr(exc))
            api.close(conn);api.release(acc)
        # Keep current limit clear even if Apple automatically updates it.
        after=snapshot()
        note(f'USB SOFT REPLUG AFTER: inputW={after.get("system_mw")}mW inputMA={after.get("system_ma")}mA batteryMA={after.get("battery_ma")}mA USBMax={after.get("usb_max_ma")}')
        threading.Thread(target=_post_restore_audit,args=('soft-replug',),daemon=True).start()
        if POWER_MARKER.exists():
            return {'ok':False,'message':'Power flags could not be confirmed restored. Watchdog running; unplug/replug if charging stays off.'}
        return {'ok':True,'message':'Software off/on command completed; check input rail to verify real charging recovery.'}


'''+needle)
assert 'import secrets' in b and 'import subprocess' in b
panel.write_text(b)
# patch native app's single command literal, size invariant; postinst already re-signs it using ldid.
app=new/'var/jb/Applications/USBChargeControl.app/USBChargeControl'
data=app.read_bytes();assert data.count(b'RESTORE\x00')==1,data.count(b'RESTORE\x00')
app.write_bytes(data.replace(b'RESTORE\x00',b'RESTART\x00',1));assert app.stat().st_size==len(data)
ctrl=new/'DEBIAN/control';ctrl.write_text(ctrl.read_text().replace('Version: 0.8.3','Version: 0.8.4').replace('restored maximum/current-base refresh and diagnostics.','experimental bounded software USB power restart on Restore, independent recovery watchdog and diagnostics.'))
# don't bundle stale cached bytecode from old version
for cache in (new/'var/jb/usr/libexec').rglob('*.pyc'):cache.unlink()
readme=new/'var/jb/usr/share/doc/uk.551.chargingratetest/README.md'
readme.write_text((readme.read_text()+'\n0.8.4: Experimental soft power off/on when Restore is pressed in the native app, with a 5-second independent recovery watchdog. No physical cable reattach is guaranteed. Only test on a spare device with battery charge and wall adapter.\n').replace('v0.8.3','v0.8.4'))
# verify Python syntax and package
for f in (backend,panel):subprocess.run(['python3','-B','-c','import ast,sys;ast.parse(open(sys.argv[1]).read())',str(f)],check=True)
for f in new.rglob('*'):
    if f.is_file() and f.suffix=='.pyc':raise AssertionError('pyc bundled')
out=root/'551UK-USB-Charge-Control-v0.8.4-Native-App.deb'
subprocess.run(['dpkg-deb','--build','--root-owner-group',str(new),str(out)],check=True)
print(out,out.stat().st_size)
